a=input("Enter a number: ")
try:
    int(a)
except ValueError:
    print("error")